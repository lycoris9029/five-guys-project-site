# Recruiting and Application Management System — Iteration 2 implementation package

CSI 5324 Software Engineering I, Baylor University, Fall 2026 — **Team 3 "Five Guys"**

| Member | Role | Use cases implemented in Iteration 2 |
|---|---|---|
| Luyu Niu | Project Manager | 4.2.1.1 Search Available Jobs, 4.2.2.1 Create and Publish a Job Posting, 4.2.3.1 Manage Accounts and Roles |
| Xinyi Chen | Requirements Engineer | 4.2.1.2 Register Account, sample job file `jobs.csv` and its loader |
| Yuting Mei | Design Engineer (UI) | 4.2.1.5 Submit Job Application, the React front end (Explore jobs, Register, My applications) |
| Spencer Hammack | Librarian | 4.2.1.7 Track Application Stage (with the StageRecord stage history) |
| Zhengshi (Peter) Chen | Quality Assurance | 4.2.2.4 Update Application Stage (replaces Respond to Job Offer), Applicant and Application entities, front end to back end integration of the recruiter and administrator pages |

Repository: https://github.com/baylor-csi5324-team3/recruiting-system
Website: https://five-guys-project-site-five-guys-si.vercel.app/
Jira: https://csi5324.atlassian.net/jira/software/projects/KAN/boards/1

This package is the `main` branch of the repository at the time of the Iteration 2 submission (GitHub Release v2.4; v2.1 added the React front end, v2.0 is the back end only, v1.0 is the Iteration 1 code).
It contains everything needed to rebuild and test the system; nothing else has to be downloaded by hand.

## 1. What you need

| Tool | Version | Check |
|---|---|---|
| Java Development Kit | 21 | `java -version` prints `21.x` |
| Internet connection | first build only | Maven and the libraries are downloaded automatically |
| Node.js (optional) | 20 or newer | only for the React front end in Section 4; `node -v` |

Maven does **not** need to be installed: the `backend` folder ships the Maven Wrapper
(`mvnw` for macOS/Linux, `mvnw.cmd` for Windows), which downloads Maven 3.9 on first use.
Node.js is only needed for the React front end (Section 4); the two plain HTML pages are served by the Java application.

## 2. Rebuild and run the tests (about 2 minutes on the first run)

Open a terminal in the `backend` folder of this package and run:

```bash
./mvnw test            # macOS / Linux
.\mvnw.cmd test        # Windows (PowerShell or cmd)
```

The build ends with

```
Tests run: 114, Failures: 0, Errors: 0, Skipped: 0
BUILD SUCCESS
```

The 114 JUnit 5 tests are listed in Section 9 of the project documentation (test classes per
layer and per member). Nothing else is created on your machine: the tests use an in-memory H2 database.

## 3. Run the system

From the same `backend` folder:

```bash
./mvnw spring-boot:run          # Windows: .\mvnw.cmd spring-boot:run
```

Wait for the log line `Development data ready`, then open:

| Page | URL | Use case |
|---|---|---|
| Submit Job Application | http://localhost:8080/submit-application.html | 4.2.1.5 (Yuting Mei), connected to the back end |
| My Applications | http://localhost:8080/applications.html | 4.2.1.7 Track Application Stage with the stage history (Spencer Hammack), connected to the back end |
| H2 database console | http://localhost:8080/h2-console | JDBC URL `jdbc:h2:mem:rams`, user `sa`, no password |

The tracking page also shows the stage history of each application (StageRecord). To move an application through the stages from the command line, see 4.2.2.4 in Section 5.

Stop the application with `Ctrl+C`. Port 8080 must be free; if it is not, start with
`./mvnw spring-boot:run -Dspring-boot.run.arguments=--server.port=8081` and use that port in the URLs.

### Sample data loaded at every start

| Account | Role | Role id (for the X-*-Id headers) | Account id (for /api/accounts/{id}) | Notes |
|---|---|---|---|---|
| admin@example.com | Administrator | 1 | 1 | Ada Admin, can change roles and statuses |
| recruiter@example.com | Recruiter | 1 | 2 | Rhea Recruiter, company "Baylor Tech" |
| applicant@example.com | Applicant | 1 | 3 | Peter Chen, two applications in the OFFER stage |
| dormant@example.com | Applicant | - | 4 | deactivated account |

Five job postings come from `backend/src/main/resources/jobs.csv` (three open, one expired, one draft).
Data lives in memory and is recreated at every start. To keep data between restarts, run the `demo` profile instead:
`./mvnw spring-boot:run -Dspring-boot.run.profiles=demo` (file database `backend/data/rams.mv.db`).

## 4. React front end (Explore jobs, Register, My applications)

The `frontend` folder holds the React user interface (Vite + TanStack). It talks to the Java back end through a dev-server proxy, so the back end from Section 3 must be running on port 8080 first. Then, in a second terminal:

```bash
cd frontend
npm install          # first time only, about 1 minute
npm run dev          # serves http://localhost:5173/ (port 5173 must be free)
```

Open http://localhost:5173/. Every page talks to the back end. Use the **role menu at the top right** to work as the seeded applicant (Peter Chen), recruiter (Rhea Recruiter, Baylor Tech) or administrator (Ada Admin); the sign-in dialog registers new accounts (4.2.1.2).

| Role | Page | Use cases |
|---|---|---|
| Applicant | Explore jobs | 4.2.1.1 Search Available Jobs (filters go to `/api/jobs/search/results`), 4.2.1.6 Save Job Posting |
| Applicant | Job → Apply | 4.2.1.5 Submit Job Application (resume upload + submission) |
| Applicant | My applications | 4.2.1.7 Track Application Stage (stage history), 4.2.1.8 Withdraw an Application |
| Applicant | My profile | 4.2.1.4 Update Applicant Profile |
| Recruiter | Job postings | 4.2.2.1 Create and Publish a Job Posting, 4.2.2.2 Manage Job Posting (edit, close) |
| Recruiter | Candidates | 4.2.2.3 Review Submitted Applications (resume download), 4.2.2.4 Update Application Stage, 4.2.2.5 Extend Job Offer |
| Administrator | User accounts | 4.2.1.8 Withdraw an Application | `POST /api/applications/{id}/withdraw` (applicant only; allowed while SUBMITTED, UNDER_REVIEW or INTERVIEW) | `curl -X POST -H "X-Applicant-Id: 1" localhost:8080/api/applications/1/withdraw` |
| 4.2.2.5 Extend Job Offer | `POST /api/applications/{id}/extend-offer` (recruiter only; from UNDER_REVIEW or INTERVIEW) | `curl -X POST -H "X-Recruiter-Id: 1" localhost:8080/api/applications/1/extend-offer` |
| 4.2.2.2 Manage Job Posting | `PUT /api/postings/{id}` (edit details), `POST /api/postings/{id}/close` | `curl -X POST -H "X-Recruiter-Id: 1" localhost:8080/api/postings/1/close` |
| 4.2.2.3 Review Submitted Applications | `GET /api/demo/applications?recruiterId=1` (applications of the recruiter's company with stage history), `GET /api/applications/{id}/resume` (resume download) | `curl -H "X-Recruiter-Id: 1" -o resume.pdf localhost:8080/api/applications/1/resume` |
| 4.2.1.4 Update Applicant Profile, 4.2.1.6 Save Job Posting | `GET/PUT /api/demo/profile/{applicantId}`, `GET/PUT /api/demo/saved/{applicantId}` | `curl localhost:8080/api/demo/profile/1` |
| 4.2.3.1 Manage Accounts and Roles |

The data these pages display comes from `/api/demo/...` (`DemoIntegrationController`); the two items that have no entity yet (saved jobs, profile headline and bio) are kept in the file `backend/data/demo-workspace.json`, everything else is in the H2 database.

## 5. REST end points (what the front end calls; usable with curl)

Login is not implemented in Iteration 2. The caller is identified by a header:
`X-Applicant-Id`, `X-Recruiter-Id` or `X-Administrator-Id` (use the ids above).
All requests and responses are JSON. Business-rule failures return HTTP 400 with `{"message": ...}`; unknown ids return 404.

| Use case | Request | Example |
|---|---|---|
| 4.2.1.1 Search Available Jobs | `GET /api/jobs/search/results?keyword=&location=&employmentType=` | `curl "http://localhost:8080/api/jobs/search/results?keyword=engineer"` |
| 4.2.1.2 Register Account | `POST /api/accounts/register` | `curl -X POST localhost:8080/api/accounts/register -H "Content-Type: application/json" -d "{\"email\":\"new@example.com\",\"password\":\"Passw0rd!\",\"role\":\"APPLICANT\",\"fullName\":\"New Person\"}"` (creates the account and the applicant profile; a recruiter also sends `companyName`) |
| 4.2.1.5 Submit Job Application | `POST /api/applications`, `GET /api/applications?applicantId=1`, `GET/POST /api/applicants/{id}/resumes` | use the page above |
| 4.2.1.7 Track Application Stage | `GET /api/applications/tracking`, `GET /api/applications/{id}` (applicant from the header) | `curl -H "X-Applicant-Id: 1" localhost:8080/api/applications/tracking` |
| 4.2.2.4 Update Application Stage | `PATCH /api/applications/{id}/stage` (recruiter only; the application must belong to the recruiter's company) | `curl -X PATCH -H "X-Recruiter-Id: 1" -H "Content-Type: application/json" -d "{\"stage\":\"ACCEPTED\"}" localhost:8080/api/applications/1/stage` (allowed moves: SUBMITTED→UNDER_REVIEW, UNDER_REVIEW→INTERVIEW/OFFER, INTERVIEW→OFFER, OFFER→ACCEPTED/DECLINED, REJECTED/WITHDRAWN from any non-final stage; every change is appended to the stage history) |
| 4.2.2.1 Create and Publish a Job Posting | `POST /api/postings`, `POST /api/postings/{id}/publish` | `curl -X POST -H "X-Recruiter-Id: 1" -H "Content-Type: application/json" -d "{\"title\":\"QA Engineer\",\"description\":\"Test the system\",\"location\":\"Waco, TX\",\"employmentType\":\"Full-time\",\"closingDate\":\"2026-12-31\"}" localhost:8080/api/postings` then `curl -X POST -H "X-Recruiter-Id: 1" localhost:8080/api/postings/6/publish` |
| 4.2.3.1 Manage Accounts and Roles | `GET /api/accounts/lookup?email=`, `PUT /api/accounts/{id}/role-status` | `curl -X PUT -H "X-Administrator-Id: 1" -H "Content-Type: application/json" -d "{\"newStatus\":\"ACTIVE\"}" localhost:8080/api/accounts/4/role-status` |

## 6. Layout of this package

```
recruiting-system/
├── README.md                 this file
├── backend/                  Spring Boot 4 / Java 21 application (Maven)
│   ├── mvnw, mvnw.cmd        Maven Wrapper
│   ├── pom.xml
│   └── src/main/java/edu/baylor/csi5324/rams/
│       ├── web/              controllers (REST end points)
│       ├── service/          use case rules
│       ├── domain/           entities (UserAccount, Applicant, Recruiter, Administrator, Company, JobPosting, Application, StageRecord, Resume)
│       ├── repository/       Spring Data JPA repositories
│       └── config/           seeder, jobs.csv loader, clock, password encoder
│   └── src/main/resources/   application.properties, jobs.csv, static/ (the two plain HTML pages)
│   └── src/test/java/        114 JUnit 5 tests
├── frontend/                 React front end (Vite + TanStack); npm run dev, proxies /api to port 8080
└── docs/                     requirements and design notes
```

The class and method names follow the sequence diagrams (Section 6) and the design class diagram (Section 7) of the project documentation.
